<div class="w-full lg:w-3/4 grid grid-cols-1 lg:grid-cols-3 gap-4 ml-0 lg:ml-6 pt-4 lg:pt-[4rem] px-12">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white p-4 rounded-[2rem] shadow-lg flex flex-col items-center product"
            data-brand-id="<?php echo e($product->brand_id); ?>" 
            data-category-id="<?php echo e($product->categories->pluck('id')->join(',')); ?>">
            <img src="<?php echo e($product->getImageUrlAttribute()); ?>" alt="<?php echo e($product->name); ?>" class="h-32 object-contain">
            <div class="mt-2 text-center items-center justify-center">
                <img src="<?php echo e($product->brand->logo_hitam_url); ?>" alt="Brand Logo" class="h-12 py-2 object-contain mx-auto">                    
                <h3 class="mt-2 font-semibold"><?php echo e($product->name); ?></h3>
                <p class="text-gray-500 text-sm"><?php echo e($product->type); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="pagination-container mt-6 px-12">
        <?php echo e($products->withQueryString()->links()); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\utensil-compro\resources\views/partials/products.blade.php ENDPATH**/ ?>