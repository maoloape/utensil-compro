<div class="flex justify-between items-center">
    <h2 class="text-lg font-semibold">Filters</h2>
    <button id="clearFilters" class="text-sm text-black border-2 border-[#009ac7] rounded-full px-4 py-2">Clear all</button>
</div>
<div class="h-0.5 w-full bg-[#009ac7] mt-4 rounded-2xl"></div>

<!-- Brand Filter -->
<div class="mt-4">
    <h3 class="font-semibold px-4">Brand</h3>
    <ul class="mt-2 brand-filter">
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="py-2 px-4 cursor-pointer" data-brand-id="<?php echo e($brand->id); ?>" data-cover-background="<?php echo e($brand->cover_background_url); ?>">
                <span>&bull;</span> <?php echo e($brand->name); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<!-- Categories Filter -->
<div class="mt-6">
    <h3 class="font-semibold px-4">Categories</h3>
    <ul class="mt-2 category-filter">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="py-2 px-4 cursor-pointer" data-category-id="<?php echo e($category->id); ?>">
                <span>&bull;</span> <?php echo e($category->name); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const brandFilters = document.querySelectorAll('.brand-filter li');
        const categoryFilters = document.querySelectorAll('.category-filter li');
        const clearButton = document.getElementById('clearFilters');

        function filterProducts() {
            const selectedBrandElement = document.querySelector('.brand-filter li.active');
            const selectedBrand = selectedBrandElement ? selectedBrandElement.dataset.brandId : null;
            const selectedCategories = Array.from(document.querySelectorAll('.category-filter li.active'))
                .map(li => li.dataset.categoryId);

            const products = document.querySelectorAll('.product');

            products.forEach(product => {
                const productBrand = product.dataset.brandId;
                const productCategories = product.dataset.categoryId ? product.dataset.categoryId.split(',') : [];

                const brandMatch = !selectedBrand || productBrand === selectedBrand;
                const categoryMatch = selectedCategories.length === 0 || selectedCategories.some(cat => productCategories.includes(cat));

                product.classList.toggle('hidden', !(brandMatch && categoryMatch));
            });
        }

        brandFilters.forEach(li => {
            li.addEventListener('click', function () {
                brandFilters.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                filterProducts();
            });
        });

        categoryFilters.forEach(li => {
            li.addEventListener('click', function () {
                this.classList.toggle('active');
                console.log('Category clicked:', this.dataset.categoryId); // Debug
                filterProducts();
            });
        });


        clearButton.addEventListener('click', function () {
            brandFilters.forEach(b => b.classList.remove('active'));
            categoryFilters.forEach(c => c.classList.remove('active'));
            filterProducts();
        });
    });
</script>
<?php /**PATH C:\laragon\www\utensil-compro\resources\views/partials/filter.blade.php ENDPATH**/ ?>