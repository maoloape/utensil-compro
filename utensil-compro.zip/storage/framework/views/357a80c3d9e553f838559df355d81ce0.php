<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('title'); ?>
    <?php echo $__env->yieldContent('style'); ?>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/logo/logo-utensil-image.png')); ?>">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            position: relative;
            font-family: "Raleway", serif;
        }

        .container{
            max-width: 1740px;
        }
    </style>
</head>
<body>
    
    <main class="w-full">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <div class="w-full">
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH C:\laragon\www\utensil-compro\resources\views/layouts/layout.blade.php ENDPATH**/ ?>