<?php

namespace App\Filament\Resources\AboutResource\Pages;

use App\Filament\Resources\AboutResource;
use Filament\Resources\Pages\ListRecords;

class IndexPage extends ListRecords
{
    protected static string $resource = AboutResource::class;

}

