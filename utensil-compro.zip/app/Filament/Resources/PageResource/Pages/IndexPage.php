<?php

namespace App\Filament\Resources\PageResource\Pages;

use App\Filament\Resources\PageResource;
use Filament\Resources\Pages\ListRecords;

class IndexPage extends ListRecords
{
    protected static string $resource = PageResource::class;

    // Anda dapat menambahkan metode atau properti lain jika diperlukan
}

